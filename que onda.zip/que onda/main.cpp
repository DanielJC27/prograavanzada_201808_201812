#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    printf("Hola Mundo \n");
    system("PAUSE");
    return EXIT_SUCCESS;
}
